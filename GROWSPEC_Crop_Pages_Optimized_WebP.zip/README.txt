GROWSPEC CROP IMAGES — REPOSITORY ASSET PACKAGE

Place images/crop-pages/*.webp in the same folder in the GitHub repository:
ghulamabbas082-ai/growspecbio

For strawberry-container-farm/index.html:
- Hero: ../../images/crop-pages/strawberry-container-cutaway.webp
- Intro photo: ../../images/crop-pages/strawberry-crop-reference.webp
- Gallery: strawberry-growing-aisle.webp and strawberry-rack-system.webp

For microgreens-container-farm/index.html:
- Hero: ../../images/crop-pages/microgreens-container-growing.webp
- Intro photo: ../../images/crop-pages/microgreens-purple-crop.webp
- Gallery: microgreens-green-crop.webp

These are derivative WebP assets based on supplied images and do not alter other pages.
Keep original repository files unless their references are verified unused.
The strawberry cutaway and some interior system views may be rendered/illustrative:
do not label them as photographs of delivered customer projects without verification.
